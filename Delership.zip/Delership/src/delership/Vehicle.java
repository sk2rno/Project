
package delership;
public class Vehicle {
// هذا الاتربيوتس حقت السيارة 
    private String make;
    private String model;
    private String color;
    private String plate;
    private double price;
    private Customer owner;

// كتابة البارامتر في الكونستركتر الاول
    public Vehicle(String make , String model , String color , double price) {
        this(make , model , color , "unknown" , price);
        // هذا حيكون الكونسترمكر بدون معرفة صاحب السيارة
    }


    public Vehicle(String make , String model , String color , String plate , double price) {
        this.make = make;
        this.model = model;
        this.color = color;
        this.plate = plate;
        this.price = price;
        // تعريف الاتربيوتس في  كونستركر الثاني
    }

// من هنا السترر والقيترر لتعريف البرايفت 
    public String getColor() {
        return color;
    }


    public void setColor(String color) {
        this.color = color;
    }


    public String getMake() {
        return make;
    }


    public void setMake(String make) {
        this.make = make;
    }


    public String getModel() {
        return model;
    }


    public void setModel(String model) {
        this.model = model;
    }


    public Customer getOwner() {
        return owner;
    }


    public void setOwner(Customer owner) {
        this.owner = owner;
    }


    public String getPlate() {
        return plate;
    }


    public void setPlate(String plate) {
        this.plate = plate;
    }


    public double getPrice() {
        return price;
    }


    public void setPrice(double price) {
        this.price = price;
    }

// هنا وضعت الاوفر رايد لاختصار الوقت بدون استدعاء كل اوبجكت لوحده  وهي تابعه لفيكل 
    @Override
    public String toString() {
        return "Vehicle{"
                + "make : " + make
                + ", model : " + model
                + ", color : " + color
                + ", plate : " + plate
                + ", price : " + price + "ريال" + '}';
    }

}