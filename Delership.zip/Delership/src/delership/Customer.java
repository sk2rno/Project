
package delership;


import java.util.ArrayList;

public class Customer {

    private  String name;
    private  String address;
    private String phone;
    private  String email;
    private double cashOnHand;
    private ArrayList<Vehicle> vehicles;

    
    


    public Customer(String name , String address , double cashInHand) {
        this(name , address , "unknown" , cashInHand );
    }


    public Customer(String name , String address , String phone , double cashInHand) {
        this(name , address , phone , "unknown" , cashInHand);
    }


    public Customer(String name , String address , String phone , String email , double cashInHand) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.cashOnHand = cashInHand;
        this.vehicles = new ArrayList<>();// كولكلين للسيارات الممولكه ويتم تخزينها في الايراي
    }

    
    
    public String getName() {
        return name;
    }
    public String getAdderss(){
        return address;
    }

    public double getCashOnHand() {
        return cashOnHand;
    }


    public ArrayList<Vehicle> getVehicles() {
        return vehicles;
    }


    public boolean doesOwn(Vehicle vehicle) {
        return this.vehicles.contains(vehicle);
    }

// من الفانكنش هنا باستدعيها لشراء من الموظف 
    public void BuyCar(Vehicle vehicle , Employee employee , boolean finance) {
              //               ما فعلته هان استدعيت فانكشن اسمها هاندل كوستمر من كلاس اومبلي     
        boolean TheyDeal = employee.handleCustomer(this , finance , vehicle);
        // هنا اذا تم الشراء او لا
                 if ( TheyDeal ) {
                        this.vehicles.add(vehicle);
                       } 
                 
                 
                 
                        
        
                 
                     
    }

//  من هنا اذا تريد زيادة كمية الفلوس من البيت
    public void bringCash(double amount) {
        System.out.println("Bring some cash from home : " + amount + "ريال");
        this.cashOnHand += amount;
    }


    public void transact(Vehicle vehicle) {
        this.cashOnHand -= vehicle.getPrice();
    }

//مع الكوستنر لطباعة جميع الببيانات المخزنه 
    @Override
    public String toString() {
        return "Customer{"
                + "name : " + name
                + ", address : " + address
                + ", phone : " + phone
                + ", email : " + email
                + ", cashOnHand : " + cashOnHand
                + ", vehicles : " + vehicles + '}' ;
    }

}

